"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { generateText } from "ai"
import { huggingface } from "@ai-sdk/huggingface"
import { Loader2 } from "lucide-react"

export default function AIGeneratorPage() {
  const [generationType, setGenerationType] = useState("lesson")
  const [skillLevel, setSkillLevel] = useState("beginner")
  const [platform, setPlatform] = useState("unity")
  const [topic, setTopic] = useState("")
  const [generatedContent, setGeneratedContent] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)

  async function generateContent() {
    if (!topic) return

    setIsGenerating(true)
    setGeneratedContent("")

    try {
      let prompt = ""

      if (generationType === "lesson") {
        prompt = `Створіть детальний урок програмування рівня ${skillLevel === "beginner" ? "початківця" : skillLevel === "intermediate" ? "середнього" : "просунутого"} про "${topic}" для ${platform === "unity" ? "C# в Unity" : "Lua в Roblox"}. Включіть приклади коду, пояснення та невелику вправу в кінці. Відповідь має бути українською мовою.`
      } else if (generationType === "homework") {
        prompt = `Створіть домашнє завдання рівня ${skillLevel === "beginner" ? "початківця" : skillLevel === "intermediate" ? "середнього" : "просунутого"} про "${topic}" для ${platform === "unity" ? "C# в Unity" : "Lua в Roblox"}. Включіть чіткі інструкції, вимоги та підказки. Відповідь має бути українською мовою.`
      } else if (generationType === "game-idea") {
        prompt = `Згенеруйте ідею гри для розробника рівня ${skillLevel === "beginner" ? "початківця" : skillLevel === "intermediate" ? "середнього" : "просунутого"} з використанням ${platform === "unity" ? "C# в Unity" : "Lua в Roblox"}. Гра повинна зосереджуватися на "${topic}". Включіть ігрові механіки, особливості та поради щодо реалізації. Відповідь має бути українською мовою.`
      }

      const { text } = await generateText({
        model: huggingface("mistralai/Mistral-7B-Instruct-v0.2"),
        prompt: prompt,
        system:
          "Ви експерт з розробки ігор, який спеціалізується на навчанні програмуванню для ігор. Надавайте детальний, точний та освітній контент українською мовою.",
      })

      setGeneratedContent(text)
    } catch (error) {
      console.error("Помилка генерації контенту:", error)
      setGeneratedContent("Вибачте, сталася помилка при генерації контенту. Будь ласка, спробуйте ще раз.")
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <main className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-8">Генератор Контенту ШІ</h1>
      <p className="text-lg text-muted-foreground mb-8">
        Генеруйте індивідуальні уроки, домашні завдання та ідеї ігор, щоб допомогти вам вивчати розробку ігор.
      </p>

      <div className="grid md:grid-cols-2 gap-8">
        <Card>
          <CardContent className="pt-6">
            <Tabs defaultValue="lesson" onValueChange={setGenerationType}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="lesson">Урок</TabsTrigger>
                <TabsTrigger value="homework">Домашнє Завдання</TabsTrigger>
                <TabsTrigger value="game-idea">Ідея Гри</TabsTrigger>
              </TabsList>

              <div className="space-y-4 mt-6">
                <div>
                  <Label htmlFor="platform">Платформа</Label>
                  <Select value={platform} onValueChange={setPlatform}>
                    <SelectTrigger id="platform">
                      <SelectValue placeholder="Оберіть платформу" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="unity">C# для Unity</SelectItem>
                      <SelectItem value="roblox">Lua для Roblox</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="skill-level">Рівень Навичок</Label>
                  <Select value={skillLevel} onValueChange={setSkillLevel}>
                    <SelectTrigger id="skill-level">
                      <SelectValue placeholder="Оберіть рівень навичок" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beginner">Початківець</SelectItem>
                      <SelectItem value="intermediate">Середній</SelectItem>
                      <SelectItem value="advanced">Просунутий</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="topic">Тема або Фокус</Label>
                  <Textarea
                    id="topic"
                    placeholder={
                      generationType === "lesson"
                        ? "напр., Рух гравця, Виявлення зіткнень"
                        : generationType === "homework"
                          ? "напр., Створення контролера персонажа, Побудова системи інвентаря"
                          : "напр., Платформер, RPG, Головоломка"
                    }
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    className="resize-none"
                    rows={3}
                  />
                </div>

                <Button onClick={generateContent} disabled={!topic || isGenerating} className="w-full">
                  {isGenerating ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Генерація...
                    </>
                  ) : (
                    `Згенерувати ${generationType === "lesson" ? "Урок" : generationType === "homework" ? "Домашнє Завдання" : "Ідею Гри"}`
                  )}
                </Button>
              </div>
            </Tabs>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <h3 className="text-lg font-medium mb-4">Згенерований Контент</h3>
            <div className="bg-muted p-4 rounded-md min-h-[300px] max-h-[500px] overflow-y-auto whitespace-pre-wrap">
              {generatedContent || "Ваш згенерований контент з'явиться тут..."}
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  )
}

