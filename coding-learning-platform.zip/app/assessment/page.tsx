"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Separator } from "@/components/ui/separator"
import { generateText } from "ai"
import { huggingface } from "@ai-sdk/huggingface"
import { Loader2, CheckCircle2, ArrowRight } from "lucide-react"

export default function AssessmentPage() {
  const [currentStep, setCurrentStep] = useState(1)
  const [platform, setPlatform] = useState("unity")
  const [answers, setAnswers] = useState({})
  const [experience, setExperience] = useState("")
  const [goals, setGoals] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [learningPlan, setLearningPlan] = useState(null)

  // Питання для оцінки
  const unityQuestions = [
    {
      question: "Який ваш рівень досвіду з C# програмуванням?",
      options: [
        "Я ніколи не програмував на C#",
        "Я маю базові знання C# (змінні, умови, цикли)",
        "Я розумію ООП в C# (класи, наслідування)",
        "Я маю досвід розробки на C# поза Unity",
      ],
    },
    {
      question: "Який ваш досвід роботи з Unity?",
      options: [
        "Я ніколи не використовував Unity",
        "Я відкривав Unity та експериментував з інтерфейсом",
        "Я створював прості проекти, слідуючи туторіалам",
        "Я самостійно створював невеликі ігри в Unity",
      ],
    },
    {
      question: "Які аспекти розробки ігор вас найбільше цікавлять?",
      options: [
        "Програмування ігрової механіки",
        "Дизайн рівнів та ігровий процес",
        "Графіка та візуальні ефекти",
        "Штучний інтелект та поведінка персонажів",
      ],
    },
    {
      question: "Які типи ігор ви хотіли б навчитися створювати?",
      options: [
        "2D платформери або аркади",
        "3D ігри від першої/третьої особи",
        "Головоломки або стратегії",
        "Мобільні казуальні ігри",
      ],
    },
  ]

  const robloxQuestions = [
    {
      question: "Який ваш рівень досвіду з Lua програмуванням?",
      options: [
        "Я ніколи не програмував на Lua",
        "Я маю базові знання Lua (змінні, умови, цикли)",
        "Я розумію таблиці та функції в Lua",
        "Я маю досвід розробки на Lua поза Roblox",
      ],
    },
    {
      question: "Який ваш досвід роботи з Roblox Studio?",
      options: [
        "Я ніколи не використовував Roblox Studio",
        "Я відкривав Roblox Studio та експериментував з інтерфейсом",
        "Я створював прості проекти, слідуючи туторіалам",
        "Я самостійно створював невеликі ігри в Roblox",
      ],
    },
    {
      question: "Які аспекти розробки в Roblox вас найбільше цікавлять?",
      options: [
        "Програмування ігрової механіки",
        "Будівництво та дизайн світу",
        "Системи економіки та монетизації",
        "Мультиплеєр та соціальна взаємодія",
      ],
    },
    {
      question: "Які типи Roblox досвіду ви хотіли б навчитися створювати?",
      options: [
        "Симулятори та тайкуни",
        "Обби (паркур) та платформери",
        "Рольові ігри та пригоди",
        "Міні-ігри та змагальні режими",
      ],
    },
  ]

  const handleAnswerChange = (questionIndex, value) => {
    setAnswers({
      ...answers,
      [questionIndex]: value,
    })
  }

  const handleNextStep = () => {
    setCurrentStep(currentStep + 1)
  }

  const handlePrevStep = () => {
    setCurrentStep(currentStep - 1)
  }

  const generateLearningPlan = async () => {
    setIsGenerating(true)

    try {
      const questionsData = platform === "unity" ? unityQuestions : robloxQuestions

      // Підготовка відповідей для промпту
      const answersText = Object.entries(answers)
        .map(([index, value]) => {
          const question = questionsData[Number.parseInt(index)].question
          const answer = questionsData[Number.parseInt(index)].options[Number.parseInt(value)]
          return `Питання: ${question}
Відповідь: ${answer}`
        })
        .join("\n\n")

      const prompt = `
Створіть персоналізований план навчання для студента, який хоче вивчати ${platform === "unity" ? "C# для Unity" : "Lua для Roblox"}.

Інформація про студента:
${answersText}

Додаткова інформація:
- Попередній досвід: ${experience || "Не вказано"}
- Цілі навчання: ${goals || "Не вказано"}

Створіть детальний план навчання, який включає:
1. Оцінку поточного рівня знань студента
2. Рекомендовані теми для вивчення (від базових до просунутих)
3. Список з 5 уроків з коротким описом кожного
4. Список з 3 домашніх завдань з коротким описом
5. Ідею фінального проекту гри, яку студент зможе створити після проходження курсу

Відповідь має бути структурованою, детальною та українською мовою.
    `

      const { text } = await generateText({
        model: huggingface("mistralai/Mistral-7B-Instruct-v0.2"),
        prompt: prompt,
        system:
          "Ви досвідчений викладач програмування та розробки ігор. Ваше завдання - створити персоналізований план навчання на основі рівня знань та цілей студента.",
      })

      setLearningPlan(text)
    } catch (error) {
      console.error("Помилка генерації плану навчання:", error)
    } finally {
      setIsGenerating(false)
    }
  }

  const questions = platform === "unity" ? unityQuestions : robloxQuestions

  return (
    <main className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-8">Оцінка Знань та Персоналізований План Навчання</h1>

      {currentStep === 1 && (
        <Card>
          <CardHeader>
            <CardTitle>Крок 1: Оберіть платформу</CardTitle>
            <CardDescription>
              Оберіть платформу, яку ви хочете вивчати, щоб ми могли адаптувати оцінку під ваші потреби.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue={platform} onValueChange={setPlatform}>
              <TabsList className="grid w-full md:w-[400px] grid-cols-2">
                <TabsTrigger value="unity">C# для Unity</TabsTrigger>
                <TabsTrigger value="roblox">Lua для Roblox</TabsTrigger>
              </TabsList>

              <TabsContent value="unity" className="mt-6">
                <p>
                  Unity - це потужний ігровий рушій, який використовує мову програмування C#. Він дозволяє створювати 2D
                  та 3D ігри для різних платформ, включаючи ПК, консолі та мобільні пристрої.
                </p>
              </TabsContent>

              <TabsContent value="roblox" className="mt-6">
                <p>
                  Roblox - це платформа для створення та гри в користувацькі ігри. Розробка в Roblox використовує мову
                  програмування Lua та дозволяє створювати різноманітні багатокористувацькі досвіди.
                </p>
              </TabsContent>
            </Tabs>
          </CardContent>
          <CardFooter>
            <Button onClick={handleNextStep}>
              Продовжити <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </CardFooter>
        </Card>
      )}

      {currentStep === 2 && (
        <Card>
          <CardHeader>
            <CardTitle>Крок 2: Оцінка знань</CardTitle>
            <CardDescription>
              Дайте відповіді на наступні питання, щоб ми могли оцінити ваш поточний рівень знань.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {questions.map((q, index) => (
                <div key={index} className="space-y-3">
                  <h3 className="font-medium">{q.question}</h3>
                  <RadioGroup
                    value={answers[index] !== undefined ? answers[index].toString() : undefined}
                    onValueChange={(value) => handleAnswerChange(index, value)}
                  >
                    {q.options.map((option, optIndex) => (
                      <div key={optIndex} className="flex items-center space-x-2">
                        <RadioGroupItem value={optIndex.toString()} id={`q${index}-opt${optIndex}`} />
                        <Label htmlFor={`q${index}-opt${optIndex}`}>{option}</Label>
                      </div>
                    ))}
                  </RadioGroup>
                  {index < questions.length - 1 && <Separator className="my-4" />}
                </div>
              ))}
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={handlePrevStep}>
              Назад
            </Button>
            <Button onClick={handleNextStep} disabled={Object.keys(answers).length < questions.length}>
              Продовжити <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </CardFooter>
        </Card>
      )}

      {currentStep === 3 && (
        <Card>
          <CardHeader>
            <CardTitle>Крок 3: Додаткова інформація</CardTitle>
            <CardDescription>
              Розкажіть нам більше про ваш досвід та цілі, щоб ми могли створити більш персоналізований план навчання.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="experience">
                  Розкажіть про ваш попередній досвід у програмуванні або розробці ігор (якщо є)
                </Label>
                <Textarea
                  id="experience"
                  placeholder="Наприклад: Я вивчав Python в школі, але не маю досвіду з C# або Unity..."
                  value={experience}
                  onChange={(e) => setExperience(e.target.value)}
                  rows={4}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="goals">Які ваші цілі у вивченні розробки ігор?</Label>
                <Textarea
                  id="goals"
                  placeholder="Наприклад: Я хочу створити свою першу 2D гру-платформер..."
                  value={goals}
                  onChange={(e) => setGoals(e.target.value)}
                  rows={4}
                />
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={handlePrevStep}>
              Назад
            </Button>
            <Button onClick={handleNextStep}>
              Продовжити <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </CardFooter>
        </Card>
      )}

      {currentStep === 4 && (
        <Card>
          <CardHeader>
            <CardTitle>Крок 4: Генерація плану навчання</CardTitle>
            <CardDescription>На основі ваших відповідей ми згенеруємо персоналізований план навчання.</CardDescription>
          </CardHeader>
          <CardContent>
            {!learningPlan && !isGenerating && (
              <div className="text-center py-8">
                <p className="mb-6">Натисніть кнопку нижче, щоб згенерувати ваш персоналізований план навчання.</p>
                <Button onClick={generateLearningPlan}>Згенерувати план навчання</Button>
              </div>
            )}

            {isGenerating && (
              <div className="text-center py-12">
                <Loader2 className="h-12 w-12 animate-spin mx-auto mb-4 text-primary" />
                <p>Генерація вашого персоналізованого плану навчання...</p>
                <p className="text-sm text-muted-foreground mt-2">Це може зайняти до хвилини.</p>
              </div>
            )}

            {learningPlan && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-primary mb-4">
                  <CheckCircle2 className="h-6 w-6" />
                  <p className="font-medium">Ваш персоналізований план навчання готовий!</p>
                </div>

                <div className="bg-muted p-6 rounded-lg whitespace-pre-wrap">{learningPlan}</div>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={handlePrevStep}>
              Назад
            </Button>
            {learningPlan && (
              <Button asChild>
                <a
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    window.print()
                  }}
                >
                  Зберегти план
                </a>
              </Button>
            )}
          </CardFooter>
        </Card>
      )}
    </main>
  )
}

