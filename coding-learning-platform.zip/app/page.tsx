import Link from "next/link"
import { ArrowRight, Code } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import HeroSection from "@/components/hero-section"
import FeatureSection from "@/components/feature-section"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col">
      <HeroSection />

      <div className="container mx-auto px-4 py-12">
        <h2 className="text-3xl font-bold text-center mb-12">Оберіть свій шлях навчання</h2>

        <div className="grid md:grid-cols-2 gap-8">
          <Card className="border-2 hover:border-primary transition-all">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Code className="h-5 w-5" />
                C# для Unity
              </CardTitle>
              <CardDescription>Вивчайте програмування на C# та розробку ігор з Unity</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <ArrowRight className="h-5 w-5 mr-2 text-primary shrink-0 mt-0.5" />
                  <span>Опануйте основи C# на прикладах розробки ігор</span>
                </li>
                <li className="flex items-start">
                  <ArrowRight className="h-5 w-5 mr-2 text-primary shrink-0 mt-0.5" />
                  <span>Вивчіть компонентну систему Unity та архітектуру ігор</span>
                </li>
                <li className="flex items-start">
                  <ArrowRight className="h-5 w-5 mr-2 text-primary shrink-0 mt-0.5" />
                  <span>Створюйте повноцінні ігри з проектами під керівництвом ШІ</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button asChild className="w-full">
                <Link href="/courses/unity">Почати вивчення C# для Unity</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card className="border-2 hover:border-primary transition-all">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Code className="h-5 w-5" />
                Lua для Roblox
              </CardTitle>
              <CardDescription>Вивчайте програмування на Lua та розробку ігор з Roblox</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <ArrowRight className="h-5 w-5 mr-2 text-primary shrink-0 mt-0.5" />
                  <span>Опануйте основи Lua на прикладах Roblox</span>
                </li>
                <li className="flex items-start">
                  <ArrowRight className="h-5 w-5 mr-2 text-primary shrink-0 mt-0.5" />
                  <span>Вивчіть Roblox Studio та робочий процес розробки ігор</span>
                </li>
                <li className="flex items-start">
                  <ArrowRight className="h-5 w-5 mr-2 text-primary shrink-0 mt-0.5" />
                  <span>Створюйте захоплюючі проекти під керівництвом ШІ</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button asChild className="w-full">
                <Link href="/courses/roblox">Почати вивчення Lua для Roblox</Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="flex justify-center">
          <Button asChild size="lg" className="mt-4">
            <Link href="/assessment">Пройти тест знань та отримати персональний план навчання</Link>
          </Button>
        </div>
      </div>

      <FeatureSection />
    </main>
  )
}

