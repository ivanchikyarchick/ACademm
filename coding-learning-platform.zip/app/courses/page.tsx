import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function CoursesPage() {
  return (
    <main className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-8">Наші Курси</h1>

      <Tabs defaultValue="unity" className="w-full">
        <TabsList className="grid w-full md:w-[400px] grid-cols-2">
          <TabsTrigger value="unity">C# для Unity</TabsTrigger>
          <TabsTrigger value="roblox">Lua для Roblox</TabsTrigger>
        </TabsList>

        <TabsContent value="unity" className="mt-6">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Початок роботи з C# та Unity</CardTitle>
                <CardDescription>Вивчіть основи програмування на C# та ігрового рушія Unity</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="mb-4">У цьому вступному курсі ви вивчите:</p>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Синтаксис та основи C#</li>
                  <li>Інтерфейс редактора Unity та робочий процес</li>
                  <li>GameObjects та Components</li>
                  <li>Основи фізики та виявлення зіткнень</li>
                  <li>Створення вашої першої 2D гри</li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button asChild>
                  <Link href="/courses/unity/beginner">Почати Курс</Link>
                </Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Розробка Ігор на Unity Середнього Рівня</CardTitle>
                <CardDescription>Створюйте більш складні ігри з просунутими концепціями C#</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="mb-4">Підніміть свої навички на новий рівень з:</p>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Об'єктно-орієнтоване програмування в C#</li>
                  <li>Нова система вводу Unity</li>
                  <li>Анімація та машини станів</li>
                  <li>Системи UI та створення меню</li>
                  <li>Створення повноцінного 3D платформера</li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button asChild>
                  <Link href="/courses/unity/intermediate">Почати Курс</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="roblox" className="mt-6">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Початок роботи з Lua та Roblox</CardTitle>
                <CardDescription>Вивчіть основи програмування на Lua та Roblox Studio</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="mb-4">У цьому вступному курсі ви вивчите:</p>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Синтаксис та основи Lua</li>
                  <li>Інтерфейс та інструменти Roblox Studio</li>
                  <li>Parts, models та workspace</li>
                  <li>Основи скриптингу на Lua</li>
                  <li>Створення вашого першого проекту в Roblox</li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button asChild>
                  <Link href="/courses/roblox/beginner">Почати Курс</Link>
                </Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Розробка в Roblox Середнього Рівня</CardTitle>
                <CardDescription>Створюйте більш складні проекти з просунутим Lua</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="mb-4">Підніміть свої навички на новий рівень з:</p>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Просунуті техніки програмування на Lua</li>
                  <li>Remote events та functions</li>
                  <li>Збереження даних та статистика гравців</li>
                  <li>Дизайн інтерфейсу з Roblox GUIs</li>
                  <li>Створення повноцінної багатокористувацької гри</li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button asChild>
                  <Link href="/courses/roblox/intermediate">Почати Курс</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </main>
  )
}

