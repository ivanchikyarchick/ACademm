import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function HeroSection() {
  return (
    <div className="relative bg-gradient-to-b from-primary/10 to-background pt-20 pb-24">
      <div className="container mx-auto px-4 text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-6">Вивчайте Розробку Ігор з ШІ</h1>
        <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto mb-10">
          Опануйте C# для Unity та Lua для Roblox з уроками, домашніми завданнями та ідеями ігрових проектів,
          згенерованими штучним інтелектом.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button asChild size="lg">
            <Link href="/assessment">Пройти Тест Знань</Link>
          </Button>
          <Button asChild size="lg" variant="outline">
            <Link href="/ai-generator">Згенерувати Ідеї Ігор</Link>
          </Button>
        </div>
      </div>

      {/* Decorative elements */}
      <div className="absolute top-1/2 left-10 -translate-y-1/2 hidden lg:block">
        <div className="w-20 h-20 rounded-full bg-primary/20 backdrop-blur-xl"></div>
      </div>
      <div className="absolute bottom-10 right-10 hidden lg:block">
        <div className="w-32 h-32 rounded-full bg-primary/10 backdrop-blur-xl"></div>
      </div>
    </div>
  )
}

