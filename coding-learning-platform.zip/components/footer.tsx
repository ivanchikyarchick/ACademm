import Link from "next/link"
import { Code, Github, Twitter, Youtube } from "lucide-react"

export default function Footer() {
  return (
    <footer className="border-t bg-muted/40">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <Link href="/" className="flex items-center gap-2 font-bold text-xl mb-4">
              <Code className="h-6 w-6" />
              <span>КодГра Академія</span>
            </Link>
            <p className="text-muted-foreground">
              Вивчайте розробку ігор з уроками, домашніми завданнями та ідеями ігор, згенерованими ШІ.
            </p>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-4">Курси</h3>
            <ul className="space-y-2">
              <li>
                <Link
                  href="/courses/unity/beginner"
                  className="text-muted-foreground hover:text-primary transition-colors"
                >
                  C# для Unity Початківців
                </Link>
              </li>
              <li>
                <Link
                  href="/courses/unity/intermediate"
                  className="text-muted-foreground hover:text-primary transition-colors"
                >
                  Середній Рівень Unity
                </Link>
              </li>
              <li>
                <Link
                  href="/courses/roblox/beginner"
                  className="text-muted-foreground hover:text-primary transition-colors"
                >
                  Lua для Roblox Початківців
                </Link>
              </li>
              <li>
                <Link
                  href="/courses/roblox/intermediate"
                  className="text-muted-foreground hover:text-primary transition-colors"
                >
                  Середній Рівень Roblox
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-4">Ресурси</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/ai-generator" className="text-muted-foreground hover:text-primary transition-colors">
                  ШІ Генератор
                </Link>
              </li>
              <li>
                <Link href="/assessment" className="text-muted-foreground hover:text-primary transition-colors">
                  Оцінка Знань
                </Link>
              </li>
              <li>
                <Link href="/community" className="text-muted-foreground hover:text-primary transition-colors">
                  Спільнота
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-muted-foreground hover:text-primary transition-colors">
                  Блог
                </Link>
              </li>
              <li>
                <Link href="/faq" className="text-muted-foreground hover:text-primary transition-colors">
                  Часті Питання
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-4">Зв'язок</h3>
            <div className="flex space-x-4 mb-4">
              <Link href="https://github.com" className="text-muted-foreground hover:text-primary transition-colors">
                <Github className="h-5 w-5" />
                <span className="sr-only">GitHub</span>
              </Link>
              <Link href="https://twitter.com" className="text-muted-foreground hover:text-primary transition-colors">
                <Twitter className="h-5 w-5" />
                <span className="sr-only">Twitter</span>
              </Link>
              <Link href="https://youtube.com" className="text-muted-foreground hover:text-primary transition-colors">
                <Youtube className="h-5 w-5" />
                <span className="sr-only">YouTube</span>
              </Link>
            </div>
            <p className="text-muted-foreground text-sm">
              Підпишіться на нашу розсилку для отримання оновлень про нові курси та функції.
            </p>
          </div>
        </div>

        <div className="border-t mt-8 pt-8 text-center text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} КодГра Академія. Усі права захищені.</p>
        </div>
      </div>
    </footer>
  )
}

