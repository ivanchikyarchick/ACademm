import { BookOpen, Code, GamepadIcon as GameController, Lightbulb, Rocket, Users } from "lucide-react"

const features = [
  {
    icon: <BookOpen className="h-10 w-10 text-primary" />,
    title: "Уроки, Згенеровані ШІ",
    description:
      "Персоналізований навчальний контент, створений штучним інтелектом відповідно до вашого рівня навичок та темпу навчання.",
  },
  {
    icon: <Code className="h-10 w-10 text-primary" />,
    title: "Практичні Вправи з Кодування",
    description:
      "Навчайтеся на практиці з практичними завданнями з кодування, які закріплюють концепції програмування.",
  },
  {
    icon: <GameController className="h-10 w-10 text-primary" />,
    title: "Ідеї Ігрових Проектів",
    description: "Отримуйте натхнення з ідей ігор, згенерованих ШІ та адаптованих до ваших поточних навичок.",
  },
  {
    icon: <Lightbulb className="h-10 w-10 text-primary" />,
    title: "Домашні Завдання",
    description: "Практикуйте вивчене з цільовими домашніми завданнями, які базуються на кожному уроці.",
  },
  {
    icon: <Users className="h-10 w-10 text-primary" />,
    title: "Навчання в Спільноті",
    description: "Приєднуйтесь до спільноти учнів, щоб ділитися ідеями, отримувати відгуки та співпрацювати.",
  },
  {
    icon: <Rocket className="h-10 w-10 text-primary" />,
    title: "Навчання на Проектах",
    description: "Створюйте повноцінні ігри від початку до кінця, вивчаючи всі аспекти розробки ігор.",
  },
]

export default function FeatureSection() {
  return (
    <div className="bg-muted/50 py-16">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Особливості Платформи</h2>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-background p-6 rounded-lg shadow-sm border">
              <div className="mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

