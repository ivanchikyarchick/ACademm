import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

export default function LearningPlanCard({ plan }) {
  if (!plan) return null

  // Функція для розбору плану на секції
  const parseSection = (title, content) => {
    if (!content) return null

    return (
      <div className="mb-6">
        <h3 className="text-lg font-semibold mb-2">{title}</h3>
        <div className="pl-4 border-l-2 border-primary/30">{content}</div>
      </div>
    )
  }

  // Спроба розбити план на логічні секції
  const sections = {
    assessment: null,
    topics: null,
    lessons: null,
    homework: null,
    project: null,
  }

  // Тут можна додати логіку для розбору тексту плану на секції
  // Для простоти, зараз просто відображаємо весь текст

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Ваш Персоналізований План Навчання</CardTitle>
        <CardDescription>План створено на основі вашої оцінки знань та цілей</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="whitespace-pre-wrap">{plan}</div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" asChild>
          <Link href="/assessment">Пройти оцінку знань знову</Link>
        </Button>
        <Button asChild>
          <Link href="/courses">
            Почати навчання <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

